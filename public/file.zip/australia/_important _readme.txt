
IMPORTANT:

When adding your map shapefiles, they need to be copied into two folders:

1. the folder "map"      (for the offline version)
2. the folder "web\map"  (for the web version)

If your map looks 'blocky' or low quality, remove the file "SHPReader.swf" and 
rename the file "SHPReader2.swf" to "SHPReader.swf". Then copy and replace this file
in the "web" directory.

See also 'Quick_Start' and the User Guide for more details.
